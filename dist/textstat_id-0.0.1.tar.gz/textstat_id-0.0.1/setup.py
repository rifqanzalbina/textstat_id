from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="textstat_id",
    version="0.0.1",
    author="rifqanzalbina",
    author_email="zalbinarifqan19@gmail.com",
    description="Library untuk analisis statistik teks Bahasa Indonesia",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rifqanzalbina/textstat_id",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "textstat_id": ["data/*.json"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Natural Language :: Indonesian",
        "Topic :: Text Processing :: Linguistic",
    ],
    python_requires=">=3.6",
    install_requires=[
        "nltk>=3.6.0",
        "pandas>=1.0.0",
    ],
    license="MIT",
)